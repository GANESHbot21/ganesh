const quizData = [
    {

        question: "What is a smart contract in the context of blockchain technology",
         a: "A legally binding document stored on the blockchain.",
         b: "A self-executing contract with the terms of the agreement directly written into code.",
         c: "A physical device used for blockchain transactions.",
         d: "A specialized computer for mining cryptocurrencies.",
         correct: "b",
    },
    {
        question: "How does a private blockchain differ from a public blockchain?",
        a: "Public blockchains are controlled by a single entity, while private blockchains are open to anyone.",
        b: "Private blockchains are open to the public, while public blockchains are restricted to specific participants.",
        c: "Public blockchains are decentralized and open, while private blockchains are restricted to a specific group of participants.",
        d: "Private and public blockchains operate in the same way with no differences.",
        correct: "c",
    },
    {
        question: "What is the role of a miner in a blockchain network?",

        a: "Record transactions",
        b: "Create smart contracts",
        c: "Verify identity",
        d: "Manage user permissions",
        correct: "a",
    }
];

const quiz = document.getElementById('quiz')
const answerEls = document.querySelectorAll('.answer')
const questionEl = document.getElementById('question')
const a_text = document.getElementById('a_text')
const b_text = document.getElementById('b_text')
const c_text = document.getElementById('c_text')
const d_text = document.getElementById('d_text')
const submitBtn = document.getElementById('submit')



let currentQuiz = 0;
let score = 0;


loadQuiz();


function loadQuiz() {
    deselectAnswers()

    const currentQuizData = quizData[currentQuiz];

    questionEl.innerText = currentQuizData.question
    a_text.innerText = currentQuizData.a
    b_text.innerText = currentQuizData.b
    c_text.innerText = currentQuizData.c
    d_text.innerText = currentQuizData.d
}



function deselectAnswers () {
    answerEls.forEach(answerEl => answerEl.checked = false)

}

function getSelected () {
    let answer
    answerEls.forEach(answerEl => {
        if (answerEl.checked) [
            answer = answerEl.id
        ]
    })
    return answer
}  


submitBtn.addEventListener('click', () => {
     const answer = getSelected()
     if(answer) {
        if (answer === quizData[currentQuiz].correct) {
            score++
        }

        currentQuiz++

        if (currentQuiz < quizData.length) {
            loadQuiz()

        } else{
            quiz.innerHTML = `
            <h2>you answered ${score}/${quizData.length} questions correctly</h2>

            <button onclick="location.reload()">Reload</button>
            `
        }
     }
})